/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   gen_num.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkamanur <gkamanur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/11 10:20:54 by gkamanur          #+#    #+#             */
/*   Updated: 2025/04/11 10:39:11 by gkamanur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
// ANSI Escape Codes for Colors
# define RESET "\x1B[0m"

// Standard Rainbow Colors
# define RED "\x1B[31m"
# define ORANGE "\x1B[38;5;214m"
# define YELLOW "\x1B[33m"
# define GREEN "\x1B[32m"
# define BLUE "\x1B[34m"
# define INDIGO "\x1B[38;5;54m"
# define VIOLET "\x1B[35m"

// Light Shades
# define LIGHT_RED "\x1B[91m"
# define LIGHT_ORANGE "\x1B[38;5;216m"
# define LIGHT_YELLOW "\x1B[93m"
# define LIGHT_GREEN "\x1B[92m"
# define LIGHT_BLUE "\x1B[94m"
# define LIGHT_INDIGO "\x1B[38;5;105m"
# define LIGHT_VIOLET "\x1B[95m"

// Dark Shades
# define DARK_RED "\x1B[38;5;88m"
# define DARK_ORANGE "\x1B[38;5;130m"
# define DARK_YELLOW "\x1B[38;5;136m"
# define DARK_GREEN "\x1B[38;5;22m"
# define DARK_BLUE "\x1B[38;5;17m"
# define DARK_INDIGO "\x1B[38;5;18m"
# define DARK_VIOLET "\x1B[38;5;53m"

// Filled (Background Colors)
# define FILLED_RED "\x1B[41m"
# define FILLED_ORANGE "\x1B[48;5;214m"
# define FILLED_YELLOW "\x1B[43m"
# define FILLED_GREEN "\x1B[42m"
# define FILLED_BLUE "\x1B[44m"
# define FILLED_INDIGO "\x1B[48;5;54m"
# define FILLED_VIOLET "\x1B[45m"

// Light Filled Backgrounds
# define FILLED_LIGHT_RED "\x1B[101m"
# define FILLED_LIGHT_ORANGE "\x1B[48;5;216m"
# define FILLED_LIGHT_YELLOW "\x1B[103m"
# define FILLED_LIGHT_GREEN "\x1B[102m"
# define FILLED_LIGHT_BLUE "\x1B[104m"
# define FILLED_LIGHT_INDIGO "\x1B[48;5;105m"
# define FILLED_LIGHT_VIOLET "\x1B[105m"

// Dark Filled Backgrounds
# define FILLED_DARK_RED "\x1B[48;5;88m"
# define FILLED_DARK_ORANGE "\x1B[48;5;130m"
# define FILLED_DARK_YELLOW "\x1B[48;5;136m"
# define FILLED_DARK_GREEN "\x1B[48;5;22m"
# define FILLED_DARK_BLUE "\x1B[48;5;17m"
# define FILLED_DARK_INDIGO "\x1B[48;5;18m"
# define FILLED_DARK_VIOLET "\x1B[48;5;53m"

// RAINBOW_COLORS_H

void generate_random_numbers(int min, int max, int count)
{
    if (min > max)
    {
        printf("%sError: Minimum limit (%d) cannot be greater than maximum limit (%d).%s\n", 
               RED, min, max, RESET);
        return;
    }
    if (count <= 0)
    {
        printf("%sError: Count must be a positive number (got %d).%s\n", 
               RED, count, RESET);
        return;
    }

    int range = max - min + 1; // Total possible numbers
    if (count > range)
    {
        printf("%sError: Count (%d) exceeds possible unique numbers in range [%d, %d] (%d).%s\n", 
               RED, count, min, max, range, RESET);
        return;
    }

    // Allocate array to track used numbers
    int *used = calloc(range, sizeof(int));
    if (!used)
    {
        printf("%sError: Memory allocation failed.%s\n", RED, RESET);
        return;
    }

    int *numbers = malloc(count * sizeof(int));
    if (!numbers)
    {
        printf("%sError: Memory allocation failed.%s\n", RED, RESET);
        free(used);
        return;
    }

    // Generate unique random numbers
    int generated = 0;
    printf("%sGenerating %d unique random numbers between %d and %d:%s\n", 
           GREEN, count, min, max, RESET);
    printf("./pushswap ");
    while (generated < count)
    {
        int random_num = min + (rand() % range);
        if (used[random_num - min] == 0) // Check if number is unused
        {
            used[random_num - min] = 1; // Mark as used
            numbers[generated] = random_num;
            generated++;
        }
    }

    // Print the numbers in green
    for (int i = 0; i < count; i++)
    {
        printf("%s%d%s", DARK_RED, numbers[i], RESET);
        if (i < count - 1)
            printf("  ");
    }
    printf("\n");

    // Clean up
    free(used);
    free(numbers);
}

int main(void)
{
    int min, max, count;

    // Seed the random number generator with current time
    srand(time(NULL));

    // Get user input
    printf("%sEnter the minimum limit: %s", RED, RESET);
    scanf("%d", &min);

    printf("%sEnter the maximum limit: %s", ORANGE, RESET);
    scanf("%d", &max);

    printf("%sEnter the number of random numbers to generate: %s", YELLOW, RESET);
    scanf("%d", &count);

    // Generate random numbers
    generate_random_numbers(min, max, count);

    return 0;
}