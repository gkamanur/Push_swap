/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_utils.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkamanur <gkamanur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/09 15:44:42 by gkamanur          #+#    #+#             */
/*   Updated: 2025/04/13 11:16:02 by gkamanur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/pushswap.h"

int	data(long int x, long int y)
{
	if (x > y)
		return (1);
	else if (x < y)
		return (2);
	else
		return (0);
}

int	sort_check(t_list **stack, int (*func)(long int, long int))
{
	t_list	*curr;

	curr = *stack;
	while (curr && curr->next)
	{
		if (func(curr->num, curr->next->num) == 1)
			return (0);
		curr = curr->next;
	}
	return (1);
}

t_list *find_min_node(t_list *s_b, int *min_pos, int *size)
{
    t_list *min_node;
    t_list *temp;
    int min_index;
    int pos;

    if (!s_b)
        return (NULL);
    min_node = s_b;
    temp = s_b;
    min_index = min_node->index;
    pos = 0;
    *min_pos = 0;
    while (temp)
    {
        if (temp->index < min_index)
        {
            min_index = temp->index;
            min_node = temp;
            *min_pos = pos;
        }
        temp = temp->next;
        pos++;
    }
    *size = pos;
    return (min_node);
}

void rotate_to_min(t_list **s_b, t_list *min_node, int min_pos, int size)
{
    if (!s_b || !*s_b || !min_node)
        return;

    if (min_pos <= size / 2)
        while (*s_b != min_node)
            rb(s_b);
    else
        while (*s_b != min_node)
            rrb(s_b);
}




