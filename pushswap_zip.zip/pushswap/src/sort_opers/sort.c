/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkamanur <gkamanur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/10 15:27:49 by gkamanur          #+#    #+#             */
/*   Updated: 2025/04/13 11:28:30 by gkamanur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/pushswap.h"

void	sort_3(t_list **stack, t_list *first, t_list *second, t_list *third)
{
	first = *stack;
	second = first->next;
	third = second->next;
	if (first->index > second->index && first->index > third->index)
		if (second->index > third->index)
		{
			ra(stack);
			sa(stack);
		}
		else
			ra(stack);
	else if (second->index > first->index && second->index > third->index)
		if (first->index > third->index)
			rra(stack);
		else
		{
			sa(stack);
			ra(stack);
		}
	else if (third->index > first->index && third->index > second->index)
		if (first->index > second->index)
			sa(stack);
}

void	sort_5(t_list **s_a, t_list **s_b)
{
	int	m_n;
	int	p;

	m_n = min(*s_a, "min2", 0);
	p = 0;
	while (*s_a && p < 2)
	{
		if (((*s_a)->index == m_n || (*s_a)->index == m_n + 1))
		{
			pb(s_a, s_b);
			p++;
		}
		else
			ra(s_a);
	}
	if (*s_b && (*s_b)->next && (data((*s_b)->index, (*s_b)->next->index) == 2))
		sb(s_b);
	sort_3(s_a, NULL, NULL, NULL);
	pa(s_a, s_b);
	pa(s_a, s_b);
}

void	perform_sort(t_list **s_a, t_list **s_b, t_value *value, int *level)
{
	if (lst_size(*s_a) == 1)
		putstr_clr("nothing to sort", 1, RED);
	else if (lst_size(*s_a) == 2)
	{
		if ((*s_a)->num > (*s_a)->next->num)
			sa(s_a);
	}
	else if (lst_size(*s_a) == 3)
		sort_3(s_a, NULL, NULL, NULL);
	else if (lst_size(*s_a) == 5)
		sort_5(s_a, s_b);
	else
	chunk_sort (s_a, s_b, value, level);
}
