/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   chunck_sort.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkamanur <gkamanur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/11 16:40:16 by gkamanur          #+#    #+#             */
/*   Updated: 2025/04/13 11:13:03 by gkamanur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/pushswap.h"

void	chunk_stack_a(t_list **s_a, t_list **s_b, t_value *p, int *level)
{
	while (p->len-- > 0)
	{
		if ((*s_a)->index > p->mid)
		{
			(*s_a)->level = *level + 1;
			pb(s_a, s_b);
		}
		else
			ra(s_a);
	}
	(*level)++;
}

void	chunk_stack_b(t_list **s_a, t_list **s_b)
{
	t_list *min_node;
	int min_pos = 0;
	int size = 0;

	if (!*s_b)
		return ;
	min_node = find_min_node(*s_b, &min_pos, &size);
	rotate_to_min(s_b, min_node, min_pos, size);
    pa(s_a, s_b);
	ra(s_a);
}

void	chunk_sort(t_list **s_a, t_list **s_b, t_value *p, int *level)
{
	p->len = lst_size(*s_a);
	if (p->len == 3)
	{
		sort_3(s_a, NULL, NULL, NULL);
		return ;
	}
	if (p->len <= 2)
	{
		if (p->len == 2 && (*s_a)->index > (*s_a)->next->index)
			sa(s_a);
		return ;
	}
	p->mid = p->len / 2;
	chunk_stack_a(s_a, s_b, p, level);
    chunk_sort(s_a, s_b, p, level);
	while (*s_b)
		chunk_stack_b(s_a, s_b);
    
}
