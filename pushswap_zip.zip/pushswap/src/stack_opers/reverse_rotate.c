/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   reverse_rotate.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkamanur <gkamanur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/09 14:41:34 by gkamanur          #+#    #+#             */
/*   Updated: 2025/04/13 12:00:43 by gkamanur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/pushswap.h"

void	reverse_rotate(t_list **stack)
{
	t_list	*last;
	t_list	*second_last;

	if (!stack || !*stack || !(*stack)->next)
		return ;
	second_last = *stack;
	last = second_last->next;
	while (last->next)
	{
		second_last = last;
		last = last->next;
	}
	second_last->next = NULL;
	last->next = *stack;
	*stack = last;
}

void	rra(t_list **s_a)
{
	reverse_rotate(s_a);
	// putstr_fd("rra\n",1);
	printf("rra\n");
}

void	rrb(t_list **s_b)
{
	reverse_rotate(s_b);
	// putstr_fd("rrb\n",1);
	printf("rrb\n");
}

void	rrr(t_list **s_a, t_list **s_b)
{
	reverse_rotate(s_a);
	reverse_rotate(s_b);
	// putstr_fd("rrr\n",1);
	printf("rrr\n");
}
