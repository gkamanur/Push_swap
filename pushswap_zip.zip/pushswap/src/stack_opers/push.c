/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkamanur <gkamanur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/09 14:59:42 by gkamanur          #+#    #+#             */
/*   Updated: 2025/04/13 12:00:10 by gkamanur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/pushswap.h"

void	pa(t_list **stack_a, t_list **stack_b)
{
	t_list	*aux;

	if (!stack_b || !*stack_b)
		return ;
	aux = *stack_b;
	*stack_b = aux->next;
	aux->next = *stack_a;
	*stack_a = aux;
	// putstr_fd("pa\n",1);
	printf("pa\n");
}

void	pb(t_list **stack_a, t_list **stack_b)
{
	t_list	*aux;

	if (!stack_a || !*stack_a)
		return ;
	aux = *stack_a;
	*stack_a = aux->next;
	aux->next = *stack_b;
	*stack_b = aux;
	// putstr_fd("pb\n",1);
	printf("pb\n");
}
