/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkamanur <gkamanur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 12:19:09 by gkamanur          #+#    #+#             */
/*   Updated: 2025/04/13 12:16:00 by gkamanur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"../../include/pushswap.h"
#include <stdio.h>

void print_stack(t_list *lst)
{
    t_list *curr = lst;
    if (!lst)
    {
        write(1, "Empty stack\n", 12);
        return;
    }
    while (curr)
    {
        printf ("[%s%li%s, %s%i%s, %s%i%s]", RED, curr->num,RESET,GREEN, curr->index, RESET, YELLOW, curr->level,RESET);
        curr = curr->next;
        if (curr)
            printf(" -> ");
    }
    printf("\n");
}

int	main(int ac, char **av)
{
    t_list *s_a;
    t_list *s_b;
    t_value value_struct;
    t_value *value = &value_struct;
    static int level;
    
    s_a = NULL;
    s_b = NULL;
    level = 0;
    if (ac == 1)
    {
		putstr_clr("🤪 🤪 🤪 Give Proper inputs!!!", 1, RED);
        return(0) ;
    }
    s_a = check_input(ac, av, s_a);
    if (!s_a)
    {
        putstr_clr("Error: Invalid input or allocation failed", 1, RED);
        return (1);
    }
    value_init(&s_a, value);
    // printf("before Index stack_a : ");
    // print_stack(s_a);
    indices(s_a);
    // printf("After Index stack_a : ");
    // print_stack(s_a);
    // exit(0);
    perform_sort(&s_a, &s_b, value, &level);
    // printf("stack_a : ");
    // print_stack(s_a);
    // printf("stack_b : ");
    // print_stack(s_b);
    free_list(&s_a);
    free_list(&s_b);
	return (0);
}

