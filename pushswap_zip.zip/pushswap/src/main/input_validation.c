/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input_validation.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkamanur <gkamanur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 13:00:32 by gkamanur          #+#    #+#             */
/*   Updated: 2025/04/13 12:27:44 by gkamanur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../include/pushswap.h"

int is_non_integer(const char *str)
{
    int i;
    int has_digit;

    if (!str || !str[0])
        return (1);
    
    i = 0;
    while (str[i] == ' ')
        i++;
    
    if (str[i] == '-')
        i++;
    
    has_digit = 0;
    while (str[i] >= '0' && str[i] <= '9')
    {
        has_digit = 1;
        i++;
    }
    
    while (str[i] == ' ')
        i++;
    
    if (str[i] || !has_digit)
        return (1);
    
    return (0);
}

int	has_duplicate(int num, t_list *list)
{
	t_list	*temp;

	temp = list;
	while (temp)
	{
		if (temp->num == num)
			return (1);
		temp = temp->next;
	}
	return (0);
}

void	load_logic(char *str, t_list **node)
{
	long int	num;
	int i = 0;
	while (str[i] == ' ')
		i++;
	str = str + i; 
	if (is_non_integer(str))
	{
		putstr_clr("👊👊👊 found non-integer..watching 👁️ 👁️", 1, YELLOW);
		exit(-1);
	}
	num = ft_atoi(str);
	if (num > INT_MAX || num < INT_MIN)
	{
		putstr_clr("👊👊👊 input exceeds the limits..watching 👁️ 👁️", 1, YELLOW);
		exit(-1);
	}
	if (has_duplicate((int)num, *node))
	{
		putstr_clr("👊👊👊 found duplicates..watching 👁️ 👁️", 1, YELLOW);
		;
		exit(-1);
	}
	*node = append_node(num, *node);
}

t_list	*check_input(int ac, char **av, t_list *list)
{
	char	**arg;
	int		i;

	arg = NULL;
	if (ac == 2)
	{
		i = 0;
		arg = ft_split(av[1], ' ');
		if (!arg)
			return (NULL);
		while (arg[i])
			load_logic(arg[i++], &list);
		free_split(arg);
		return (list);
	}
	if (ac > 2)
	{
		i = 1;
		while (av[i])
			load_logic(av[i++], &list);
		return (list);
	}
	return (list);
}
