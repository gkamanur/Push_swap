/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pick_node.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkamanur <gkamanur@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/08 10:58:46 by gkamanur          #+#    #+#             */
/*   Updated: 2025/04/13 12:15:02 by gkamanur         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include"../../include/pushswap.h"

int min(t_list *list, char *str, int res)
{
    if (!list)
        return (INT_MAX); // Changed to INT_MAX to avoid confusion with num = -1
    res = INT_MAX;
    if (ft_strcmp(str, "min1") == 0)
    {
        while (list)
        {
            if (list->index == -1 && list->num < res)
                res = list->num;
            list = list->next;
        }
        return (res); // Returns INT_MAX if no valid nodes
    }
    if (ft_strcmp(str, "min2") == 0)
    {
        while (list)
        {
            if (list->index < res)
                res = list->index;
            list = list->next;
        }
        return (res);
    }
    return (INT_MAX);
}

int max(t_list *list, char *str, int res)
{
    if (!list)
        return (-1);
    res = INT_MIN;
    if (ft_strcmp(str, "max1") == 0)
    {
        while (list)
        {
            if (list->index == -1 && list->num > res)
                res = list->num;
            list = list->next;
        }
        return (res);
    }
    if (ft_strcmp(str, "max2") == 0)
    {
        while (list)
        {
            if (list->index > res)
                res = list->index;
            list = list->next;
        }
        return (res);
    }
    return (-1);
}

t_list *min_node(t_list *lst)
{
    t_list *curr;
    int min_val;

    if (!lst)
        return (NULL);
    min_val = min(lst, "min1", 0);
    if (min_val == INT_MAX) // No nodes with index == -1
        return (NULL);
    curr = lst;
    while (curr)
    {
        if (curr->index == -1 && curr->num == min_val)
            return (curr); // Return first matching node
        curr = curr->next;
    }
    return (NULL); // No matching node found
}

t_list *indices(t_list *lst)
{
    t_list *min;
    int index;

    if (!lst)
        return (NULL);
    index = 0;
    while (1)
    {
        min = min_node(lst);
        if (!min)
            break; // No more nodes to index
        min->index = index;
        index++;
    }
    return (lst);
}

void    value_init(t_list **stack, t_value *value)
{
    value->len = lst_size(*stack);
    value->max = 0;
    value->min = 0;
    value->mid = 0;
}
