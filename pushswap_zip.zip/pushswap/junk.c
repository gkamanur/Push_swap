// void    sort_recur(t_list **s_a, t_list **s_b)
// {
//     int m_x;
    
//     if (lst_size(*s_b) == 0)
//         return ;
//     m_x =  max(*s_a, "max2", 0);
//     if (lst_size(*s_b) == 1 && (*s_b)->index == m_x + 1)
//     {
//         pa(s_a, s_b);
//         ra(s_a);
//         return;
//     }
//     if ((*s_b)->index == m_x + 1)
//     {
//         pa(s_a, s_b);
//         ra(s_a);
//     }
//     else if (((*s_b)->next->index == m_x + 1)
//         && ((*s_b)->index == m_x + 2))
//     {
//         sb(s_b);
//         pa(s_a, s_b);
//         ra(s_a);
        
//     }
//     else if (lastnode(*s_b)->index == m_x + 1)
//     {
//         rrb(s_b);
//         pa(s_a, s_b);
//         ra(s_a);
//     }
//     else
//         rb(s_b);
//     sort_recur(s_a, s_b);
// }